<?php
 require_once('bookmark_fns.php');
 do_html_header('');

 display_site_info(); 
 display_login_form();

 do_html_footer();
?>